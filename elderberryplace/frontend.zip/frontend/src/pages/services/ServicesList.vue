<template>
  <section>
    <h2>Services</h2>
    <p>Coming soon…</p>
  </section>
</template>