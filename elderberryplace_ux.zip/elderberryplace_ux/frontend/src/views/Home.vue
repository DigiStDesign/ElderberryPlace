<template>
  <section class="section container">
    <h1 style="color:var(--blue)">Welcome to Elderberry Place</h1>
    <p>Compassionate, personalised care in a warm and welcoming environment.</p>

    <div class="grid-2" style="margin-top:24px">
        
      <article id="residential" class="card">
        <h2>Residential Care</h2>
        <ul class="feature-list">
          <li>24/7 professional care & support</li>
          <li>Medication management</li>
          <li>Social events & community life</li>
        </ul>
      </article>

      <article id="homecare" class="card">
        <h2>Home Care</h2>
        <ul class="feature-list">
          <li>Nursing & personal care</li>
          <li>Domestic assistance & cleaning</li>
          <li>Transport to appointments</li>
        </ul>
      </article>

    </div>
  </section>
</template>