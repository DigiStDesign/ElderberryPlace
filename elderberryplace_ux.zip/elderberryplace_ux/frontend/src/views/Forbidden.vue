<template>
  <section class="container section">
    <h1>403 — Access denied</h1>
    <p class="lead">You don’t have permission to view this page.</p>
    <RouterLink class="btn btn--secondary" to="/">Back to home</RouterLink>
  </section>
</template>