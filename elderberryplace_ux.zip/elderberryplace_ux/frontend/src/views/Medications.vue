<template>
  <section class="container section">
    <header class="section-head">
      <h1>Medication Tracking</h1>
      <div class="actions">
        <button class="btn btn--secondary">Add medication</button>
      </div>
    </header>

    <div class="card">
      <table class="table">
        <thead>
          <tr>
            <th>Resident</th>
            <th>Medication</th>
            <th>Dose</th>
            <th>Schedule</th>
            <th>Last Given</th>
            <th>Next Due</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Mary Jones</td>
            <td>Amoxicillin</td>
            <td>500 mg</td>
            <td>8am / 8pm</td>
            <td>Today 08:05</td>
            <td>Today 20:00</td>
            <td><span class="badge badge--success">On time</span></td>
          </tr>
          <tr>
            <td>Peter Chen</td>
            <td>Metformin</td>
            <td>850 mg</td>
            <td>7am</td>
            <td>Today 07:10</td>
            <td>Tomorrow 07:00</td>
            <td><span class="badge badge--warn">Check</span></td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>