<template>
  <section class="container section">
    <header class="section-head">
      <h1>Invoices</h1>
      <div class="actions">
        <button class="btn btn--primary">
          Generate invoice
        </button>
      </div>
    </header>

    <div class="card">
      <table class="table">
        <thead>
          <tr>
            <th>Invoice #</th>
            <th>Resident</th>
            <th>Date</th>
            <th>Status</th>
            <th class="text-right">Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>INV-10021</td>
            <td>Mary Jones</td>
            <td>2025-03-02</td>
            <td><span class="badge badge--success">Paid</span></td>
            <td class="text-right">$1,250.00</td>
          </tr>
          <tr>
            <td>INV-10022</td>
            <td>Peter Chen</td>
            <td>2025-03-05</td>
            <td><span class="badge badge--warn">Due</span></td>
            <td class="text-right">$980.00</td>
          </tr>
          <tr>
            <td>INV-10023</td>
            <td>Sam Patel</td>
            <td>2025-03-08</td>
            <td><span class="badge">Draft</span></td>
            <td class="text-right">$730.00</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>