<template>
  <section class="section container">
    <h1>Staff Login</h1>
    <p>Stub page — hook up to your auth when ready.</p>
  </section>
</template>