<template>
  <section class="section container">
    <h1>Visitor Login</h1>
    <p>Stub page — hook up to your auth when ready.</p>
  </section>
</template>