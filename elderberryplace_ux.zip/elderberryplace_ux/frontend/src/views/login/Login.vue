<template>
  <section class="container" style="max-width:640px;margin:2rem auto;">
    <h1 class="h2">Sign in</h1>
    <form @submit.prevent="onSubmit" class="card" style="padding:1rem; margin-top:1rem;">
      <div class="form-group">
        <label for="user">Username</label>
        <input id="user" v-model.trim="username" class="input" autocomplete="username" required />
      </div>

      <div class="form-group">
        <label for="pass">Password</label>
        <input id="pass" v-model="password" class="input" type="password" autocomplete="current-password" required />
      </div>

      <div v-if="errorMsg" class="alert alert--error" role="alert">{{ errorMsg }}</div>

      <button class="btn btn--primary" :disabled="loading">
        {{ loading ? 'Signing in…' : 'Sign in' }}
      </button>
    </form>
  </section>
</template>

<script setup>
import { ref } from 'vue'
import api from '@/api/client'       // make sure frontend/api/client.js exists
import { useRouter, useRoute } from 'vue-router'
import { useAuth } from '@/auth/useAuth'

const router = useRouter()
const { login } = useAuth()

const username = ref('')
const password = ref('')
const loading  = ref(false)
const errorMsg = ref('')

async function onSubmit () {
  errorMsg.value = ''
  loading.value = true
  try {
    // fetch CSRF (optional but good practice with your API)
    await api.get('/csrf').then(r => {
      if (r.data?.data?.csrf) localStorage.setItem('csrf', r.data.data.csrf)
    })

    const { data } = await api.post('/auth/login', {
      username: username.value,
      password: password.value
    })

    const user = data?.data?.user
    if (!user) throw new Error('No user returned')
    if (data?.data?.csrf) localStorage.setItem('csrf', data.data.csrf)
    
    // Use auth system to set user
    login(user)

    const role = (user.role || '').toLowerCase()
    const dest = {
      admin:    '/invoices',
      staff:    '/schedules',       // adjust if you use a different route
      resident: '/family-portal',
      visitor:  '/contact'
    }[role] || '/'

    router.replace(dest)
  } catch (e) {
    errorMsg.value = 'Login failed. Check username/password.'
    console.error(e)
  } finally {
    loading.value = false
  }
}
</script>