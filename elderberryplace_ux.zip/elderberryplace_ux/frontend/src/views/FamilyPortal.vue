<template>
  <section class="container section">
    <h1>Family Portal</h1>
    <p class="lead">Share updates, appointments, and notes with family members.</p>

    <div class="grid-2">
      <div class="card">
        <h2>Resident</h2>
        <dl class="props">
          <div><dt>Name</dt><dd>Mary Jones</dd></div>
          <div><dt>Room</dt><dd>East Wing 12</dd></div>
          <div><dt>Primary Contact</dt><dd>Anna Jones (daughter)</dd></div>
        </dl>
      </div>

      <div class="card">
        <h2>Upcoming Appointments</h2>
        <ul class="list">
          <li>GP Checkup — 18 Mar, 10:30am</li>
          <li>Physio — 22 Mar, 2:00pm</li>
          <li>Community Garden — 26 Mar, 11:00am</li>
        </ul>
      </div>
    </div>

    <div class="card">
      <h2>Messages</h2>
      <form class="form-grid">
        <label>Subject
          <input type="text" placeholder="e.g. Visiting on Saturday" />
        </label>
        <label class="col-span-2">Message
          <textarea rows="4" placeholder="Type your message…"></textarea>
        </label>
        <div class="col-span-2">
          <button class="btn btn--primary">Send</button>
          <button class="btn btn--secondary" type="button">Back to home</button>
        </div>
      </form>
    </div>
  </section>
</template>