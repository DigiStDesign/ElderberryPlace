<template>
  <section class="section container">
    <h1>Contact</h1>
    <p class="lead">We’d love to hear from you. Send us a message and we’ll get back to you.</p>

    <form class="contact-form" @submit.prevent="submit">
      <div class="form-grid">
        <label>
          <span>Full name</span>
          <input v-model.trim="form.name" type="text" required placeholder="Your name" />
        </label>

        <label>
          <span>Email</span>
          <input v-model.trim="form.email" type="email" required placeholder="you@example.com" />
        </label>

        <label class="full">
          <span>Service of interest</span>
          <select v-model="form.service" required>
            <option value="" disabled>Select a service</option>
            <option>Residential Care</option>
            <option>Home Care</option>
          </select>
        </label>

        <label class="full">
          <span>Your message</span>
          <textarea v-model.trim="form.message" rows="6" placeholder="How can we help?" required></textarea>
        </label>
      </div>

      <div class="actions">
        <button class="btn btn--primary" type="submit">
            <i class="fa-solid fa-paper-plane"></i>Send enquiry
        </button>
        <RouterLink class="btn btn--secondary" to="/"><i class="fa-solid fa-arrow-left"></i>Back to home
        </RouterLink>

      </div>
    </form>

    
  </section>
</template>

<script setup>
import { reactive } from 'vue'
const form = reactive({
  name: '', email: '', service: '', message: ''
})
function submit(){
  // TODO: wire to your API
  alert(`Thanks, ${form.name}! We received your message about ${form.service || 'our services'}.`)
}
</script>

 <style scoped>

.lead { 
    margin-top: 6px; 
    margin-bottom: 22px; 
    color:#444; 
}

/* Form layout */
.contact-form { 
    background:#fff; 
    border:1px solid var(--grey-300); 
    border-radius:16px; 
    padding:20px; 
    box-shadow:0 4px 10px rgba(0,0,0,.05); 
}

.form-grid { 
    display:grid; 
    grid-template-columns: 1fr 1fr; 
    gap:16px; 
}

.form-grid .full { 
    grid-column: 1 / -1; 
}

label span { 
    display:block; 
    font-weight:600; 
    margin-bottom:6px; 
    color:#111; 
}

input, select, textarea {
  width:100%; 
  padding:12px 14px; 
  border-radius:12px;
  border:2px solid var(--blue); 
  background:#fff; 
  font-size:1rem;
}

input:focus-visible, select:focus-visible, textarea:focus-visible { 
    outline:none; 
    box-shadow:0 0 0 2px var(--orange); 
}

/* Actions */
.actions { 
    display:flex; 
    gap:12px; 
    margin-top:16px; 
}

select {
  appearance: none;         /* removes native arrow (cross-browser) */
  -webkit-appearance: none;
  -moz-appearance: none;
  background-color: #fff;
  background-image: url("data:image/svg+xml;utf8,<svg fill='black' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/></svg>");
  background-repeat: no-repeat;
  background-position: right 16px center;
  background-size: 34px 34px;
  padding-right: 36px;   /* make space for the arrow */
}

</style>