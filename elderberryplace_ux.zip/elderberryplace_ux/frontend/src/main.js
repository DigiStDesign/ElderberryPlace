import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { registerGuards } from './router/guards'
import { useAuth } from './auth/useAuth'
import './assets/style.css'   // global styles

// Initialize auth state from localStorage
const { initAuth } = useAuth()
initAuth()

// Register route guards
registerGuards(router)

createApp(App).use(router).mount('#app')