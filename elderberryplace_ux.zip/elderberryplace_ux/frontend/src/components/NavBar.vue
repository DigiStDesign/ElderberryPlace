<template>
  <nav class="stickynav" aria-label="Primary" ref="navRef">
    <div class="navbar container">
      <!-- Brand (left) -->
      <RouterLink to="/" class="brand" aria-label="Home">
        <img src="/ebicon.png" alt="" aria-hidden="true" />
        <span class="brand-text">Elderberry Place</span>
      </RouterLink>

      <!-- Nav links (center) -->
      <div class="nav-links" role="navigation">
        <!-- Home -->
        <RouterLink
          to="/"
          :class="['btn','btn--secondary', isActive('/') && 'active']"
        >
          <i class="fa-solid fa-house"></i> Home
        </RouterLink>

        <!-- Services dropdown -->
        <div class="dropdown"
             @keydown.esc="open.services=false"
             @focusout="onBlur('services', $event)">
          <button class="dropbtn btn btn--secondary"
                  :aria-expanded="open.services ? 'true' : 'false'"
                  @click.stop="toggle('services')">
            <i class="fa-solid fa-hand-holding-heart"></i>
            Services
            <span aria-hidden="true">▼</span>
          </button>
          <ul class="dropdown-list" role="menu" v-show="open.services" @click="closeAll">
            <li><a class="btn btn--primary" href="/#residential" role="menuitem">Residential Care</a></li>
            <li><a class="btn btn--primary" href="/#homecare" role="menuitem">Home Care</a></li>
          </ul>
        </div>

        <!-- Contact -->
        <RouterLink
          to="/contact"
          :class="['btn','btn--secondary', isActive('/contact') && 'active']"
        >
          <i class="fa-solid fa-envelope"></i> Contact
        </RouterLink>

        <!-- Login dropdown -->
        <div class="dropdown login"
             @keydown.esc="open.login=false"
             @focusout="onBlur('login', $event)">
          <button class="dropbtn btn btn--secondary"
                  :aria-expanded="open.login ? 'true' : 'false'"
                  @click.stop="toggle('login')">
            <i class="fa-solid fa-user"></i>
            Login <span aria-hidden="true">▼</span>
          </button>
          <!-- Alternate Login dropdown list with separate routes per role 
          <ul class="dropdown-list" role="menu" v-show="open.login" @click="closeAll">
            <li><RouterLink class="btn btn--primary" :to="{ name:'login-admin' }">Admin</RouterLink></li>
            <li><RouterLink class="btn btn--primary" :to="{ name:'login-staff' }">Staff</RouterLink></li>
            <li><RouterLink class="btn btn--primary" :to="{ name:'login-resident' }">Resident</RouterLink></li>
            <li><RouterLink class="btn btn--primary" :to="{ name:'login-visitor' }">Visitor</RouterLink></li>
          </ul> -->
          <!-- Login dropdown list -->
            <ul class="dropdown-list" role="menu" v-show="open.login">
              <li><RouterLink class="btn btn--primary" :to="{ name:'login', query:{ as:'admin' } }">Admin</RouterLink></li>
              <li><RouterLink class="btn btn--primary" :to="{ name:'login', query:{ as:'staff' } }">Staff</RouterLink></li>
              <li><RouterLink class="btn btn--primary" :to="{ name:'login', query:{ as:'resident' } }">Resident</RouterLink></li>
              <li><RouterLink class="btn btn--primary" :to="{ name:'login', query:{ as:'visitor' } }">Visitor</RouterLink></li>
            </ul>
        </div>
      </div>

      <!-- Site search (right) -->
      <form class="site-search" role="search" @submit.prevent="siteSearch">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="search" v-model.trim="q" placeholder="Search…" aria-label="Search site" />
        <button type="submit" class="btn btn--primary search-btn">
          <i class="fa-solid fa-arrow-right"></i>
          <span>Go</span>
        </button>
      </form>
    </div>
  </nav>
</template>

<script setup>
import { reactive, ref, onMounted, onBeforeUnmount } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()

// open/close state for dropdowns
const open = reactive({ services: false, login: false })
const navRef = ref(null)

// active route helper
function isActive(path) {
  return route.path === path
}

// close all menus
function closeAll() {
  open.services = false
  open.login = false
}

// toggle a menu (only one open at a time)
function toggle(key) {
  if (key === 'services') open.login = false
  if (key === 'login') open.services = false
  open[key] = !open[key]
}

// close when focus leaves the dropdown
function onBlur(key, e) {
  // if focus moved outside this dropdown, close
  if (!e.currentTarget.contains(e.relatedTarget)) {
    open[key] = false
  }
}

// click outside / Esc closes menus
function handleDocClick(e) {
  if (!navRef.value?.contains(e.target)) closeAll()
}
function handleKeydown(e) {
  if (e.key === 'Escape') closeAll()
}
router.afterEach(() => closeAll())

onMounted(() => {
  document.addEventListener('click', handleDocClick)
  document.addEventListener('keydown', handleKeydown)
})
onBeforeUnmount(() => {
  document.removeEventListener('click', handleDocClick)
  document.removeEventListener('keydown', handleKeydown)
})

// search
const q = ref('')
function siteSearch() {
  if (!q.value) return
  const host = location.hostname || 'example.com'
  const url = 'https://www.google.com/search?q=' +
              encodeURIComponent(`site:${host} ${q.value}`)
  window.open(url, '_self')
}

// useAuth is a custom composable for authentication state; it returns an object with 'isLoggedIn' (boolean) and 'role' (string or null) for the current user.
// import { useAuth } from '@/auth/useAuth'
// const { isLoggedIn, role } = useAuth()
// const hasRole = (...allowed) => role && role.value && allowed.includes(role.value)
</script>

<style scoped>
/* container helper if you use one globally */
.container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

/* sticky bar */
.stickynav {
  position: sticky; top: 0; z-index: 1000;
  background: #fff; border-bottom: 1px solid #e5e7eb;
  min-height: 74px; /* slightly taller */
}
.navbar {
  display: flex;
  align-items: center;
  padding: 0;
  gap: 0;
  min-height: 74px; /* match stickynav for consistent height */
}

/* brand */
.brand {
  flex: 0 0 auto;
  margin-right: 0;
  display: flex;
  align-items: center; /* vertical centering */
  gap: 10px;
  text-decoration: none;
}
.brand img { height: 28px; width: auto; }
.brand span { color: var(--blue); font-weight: 800; }

/* links row */
.nav-links {
  flex: 1 1 0;
  display: flex;
  align-items: center; /* vertical centering */
  justify-content: center;
  gap: 14px;
  min-width: 0;
}

/* dropdown */
.dropdown { position: relative; display: flex; align-items: center; } /* vertical centering */
.dropdown-list {
  position: absolute; top: calc(100% + 8px); left: 0;
  background: #fff; border: 1px solid #e5e7eb; border-radius: 16px;
  box-shadow: 0 12px 30px rgba(0,0,0,.15);
  padding: 8px 0; min-width: 240px; z-index: 1001;
}
.dropdown-list li { margin: 6px 10px; } /* spacing between items */
.dropdown-list .btn { width: 100%; }

/* search */
.site-search {
  flex: 0 0 auto;
  margin-left: auto;
  display: flex;
  align-items: center; /* vertical centering */
  height: 40px;
  width: clamp(220px, 24vw, 340px);
  border: 2px solid var(--blue);
  border-radius: 999px;
  background: #fff;
  padding: 0 0 0 10px;
  gap: 0;
  /* Remove orange outline on focus for input itself */
}
.site-search input {
  border: none;
  outline: none;
  flex: 1 1 0;
  min-width: 0;
  height: 100%;
  padding: 0 8px;
  font-size: 1rem;
  box-shadow: none !important; /* Remove any orange shadow */
}
.site-search input:focus {
  outline: none;
  box-shadow: none !important; /* Remove orange ring on input */
}
.site-search:focus-within { box-shadow: 0 0 0 2px var(--orange); }

/* active pill ring on current page */
.btn.btn--secondary.active {
  box-shadow: inset 0 0 0 2px var(--orange);
}

/* Responsive: center search bar and add gap above on small screens */
@media (max-width: 700px) {
  /* ...existing code... */
  .site-search {
    width: 100%;
    margin: 18px auto 0 auto; /* gap above and center horizontally */
    border-radius: 18px;
    justify-content: center;
  }
  /* ...existing code... */
}
</style>