<template>
  <footer class="site-footer">
    <!-- 3 columns in one grid wrapper -->
    <div class="container footer-grid">
      <!-- Left: brand -->
      <div class="footer-brand">
        <RouterLink to="/" class="brand brand--footer" aria-label="Home">
          <!-- if the file is in /public/img use /img/ebicon.png -->
          <span class="brand-text">Elderberry Place</span>
        </RouterLink>
        <p class="tagline">Home. Community. Connection.</p>
      </div>

      <!-- Middle: links -->
      <nav class="footer-links" aria-label="Footer">
        <h3>Pages</h3>
        <RouterLink to="/">Home</RouterLink>
        <!-- hash links: use path + hash for Vue Router -->
        <RouterLink :to="{ path: '/', hash: '#residential' }">Residential Care</RouterLink>
        <RouterLink :to="{ path: '/', hash: '#homecare' }">Home Care</RouterLink>
        <RouterLink to="/contact">Contact</RouterLink>
      </nav>

      <!-- Right: contact -->
      <div class="footer-contact">
        <h3>Contact</h3>
        <p>Email: <a href="mailto:hello@elderberryplace.example">hello@elderberryplace.example</a></p>
        <p>Phone: (00) 0000 0000</p>
        <button class="btn btn--primary" type="button" @click="emailUs"><i class="fa-solid fa-envelope"></i>Email us</button>
      </div>
    </div>

    <div class="footer-bottom">
      <div class="container fb-row">
        <small>© 2025 Elderberry Place. All rights reserved.</small>
        <a href="#" class="back-top" @click.prevent="toTop">Back to top ↑</a>
      </div>
    </div>
  </footer>
</template>

<script setup>
function toTop(){ window.scrollTo({ top: 0, behavior: 'smooth' }) }
function emailUs(){ location.href = 'mailto:hello@elderberryplace.example' }
</script>

<style scoped>
/* --- Layout / contrast --- */
.site-footer{
  background:#0A3B7A;            /* deep brand blue */
  color:#FDFDFD;
  border-top:4px solid var(--orange);
  margin-top:32px;
}
.container{ max-width:1200px; margin:0 auto; padding:0 20px; }
.footer-grid{
  display:grid;
  grid-template-columns:1.4fr 1fr 1fr;
  gap:24px;
  padding:28px 0;
}

/* brand block */
.brand--footer{ display:flex; align-items:center; gap:10px; text-decoration:none; }
.brand--footer img{ height:24px; width:auto; }
.brand-text{ font-weight:800; color:#fff; font-size:1rem; }
.brand--footer:hover{ text-decoration:underline; }
.tagline{ margin:6px 0 0; color:#F3F6FA; }

/* links */
.footer-links{ display:flex; flex-direction:column; gap:8px; }
.footer-links h3,
.footer-contact h3{ color:#fff; margin:0 0 8px; }
.footer-links a{ color:#fff; text-decoration:none; }
.footer-links a:hover{ text-decoration:underline; }

/* contact */
.footer-contact p{ margin:6px 0; }
.site-footer .btn.btn--primary{
  display:inline-flex;            /* stop full-width stretch */
  align-items:center; justify-content:center;
  background:#fff; color:#004AAD;
  border:2px solid #fff; border-radius:999px;
  min-height:44px; padding:8px 16px; font-weight:700;
}
.site-footer .btn.btn--primary:hover{ background:#F3F6FA; }

/* bottom strip */
.footer-bottom{ background:rgba(0,0,0,.18); border-top:1px solid rgba(255,255,255,.35); }
.fb-row{ display:flex; justify-content:space-between; align-items:center; padding:10px 0; }
.fb-row small, .fb-row a{ color:#fff; }
.back-top:hover{ text-decoration:underline; }

/* keep nav ring out of footer brand */
:global(.site-footer a.router-link-exact-active),
:global(.site-footer a.is-active){ box-shadow:none !important; }

/* responsive */
@media (max-width: 900px){
  .footer-grid{ grid-template-columns:1fr; }
}
</style>