// src/auth/roles.js
export const ROLES = {
  ADMIN: 'ADMIN',
  STAFF: 'STAFF',
  RESIDENT: 'RESIDENT',
  VISITOR: 'VISITOR',
}