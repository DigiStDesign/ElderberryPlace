// src/auth/useAuth.js
import { reactive, computed } from 'vue'

const state = reactive({
  user: null,
})

export function useAuth() {
  const isLoggedIn = computed(() => !!state.user)
  const role = computed(() => state.user?.role || null)
  const user = computed(() => state.user)
  
  // Initialize from localStorage if available
  const initAuth = () => {
    const savedUser = localStorage.getItem('user')
    if (savedUser) {
      try {
        state.user = JSON.parse(savedUser)
      } catch (e) {
        localStorage.removeItem('user')
      }
    }
  }
  
  const login = (userData) => {
    state.user = userData
    localStorage.setItem('user', JSON.stringify(userData))
  }
  
  const logout = () => {
    state.user = null
    localStorage.removeItem('user')
    localStorage.removeItem('csrf')
  }
  
  return { 
    state, 
    isLoggedIn, 
    role, 
    user,
    login,
    logout,
    initAuth
  }
}