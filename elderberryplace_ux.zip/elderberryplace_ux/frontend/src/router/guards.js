// src/router/guards.js
import { useAuth } from '@/auth/useAuth'
import { ROLES } from '@/auth/roles'

export function registerGuards(router) {
  router.beforeEach((to, from, next) => {
    const { user } = useAuth()

    // Define which roles can access which routes
    const accessRules = {
      '/invoices': [ROLES.ADMIN],
      '/medications': [ROLES.STAFF, ROLES.ADMIN],
      '/family-portal': [ROLES.RESIDENT],
    }

    const allowed = accessRules[to.path]
    if (!allowed) return next() // route unrestricted

    if (!user.value || !allowed.includes(user.value.role)) {
      return next('/403') // forbidden
    }

    next()
  })
}