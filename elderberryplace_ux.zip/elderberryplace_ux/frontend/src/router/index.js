// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'

// Lazy-loaded views (using @ alias → maps to /src)
const Home         = () => import('../views/Home.vue')
const Contact      = () => import('../views/Contact.vue')

const Login        = () => import('../views/login/Login.vue')
const Admin        = () => import('../views/login/Admin.vue')
const Staff        = () => import('../views/login/Staff.vue')
const Resident     = () => import('../views/login/Resident.vue')
const Visitor      = () => import('../views/login/Visitor.vue')

const Invoices     = () => import('../views/Invoices.vue')
const FamilyPortal = () => import('../views/FamilyPortal.vue')
const Medications  = () => import('../views/Medications.vue')

const Forbidden    = () => import('../views/Forbidden.vue')
// Optional: if you actually have a Schedules page, uncomment this
// const Schedules    = () => import('../views/Schedules.vue')

// Create router instance
const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/',               name: 'home',           component: Home },
    { path: '/contact',        name: 'contact',        component: Contact },

    // Auth & role pages
    { path: '/login',          name: 'login',          component: Login },
    {
      path: '/login/:role(admin|staff|resident|visitor)',
      name: 'login-role',
      component: Login,
    },
    // Feature pages / landings by role
    { path: '/invoices',       name: 'invoices',       component: Invoices },
    { path: '/family-portal',  name: 'family-portal',  component: FamilyPortal },
    { path: '/medications',    name: 'medications',    component: Medications },
    // { path: '/schedules',    name: 'schedules',     component: Schedules }, // if you add it
    { path: '/403', name: 'forbidden', component: Forbidden   }, // 403 Forbidden page
    // Catch-all → keep LAST
    { path: '/:pathMatch(.*)*', redirect: '/' },
  ],
  scrollBehavior: () => ({ top: 0 }),
})

export default router