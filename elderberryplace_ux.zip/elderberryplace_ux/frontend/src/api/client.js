import axios from 'axios'

const api = axios.create({
  // because of the Vite proxy, this is SAME-ORIGIN during dev:
  baseURL: '/api/index.php?r=v1',
  headers: { 'Content-Type': 'application/json' },
  withCredentials: true, // send/receive PHP session cookie
})

// Attach CSRF token automatically to non-GET requests if there is one
api.interceptors.request.use((cfg) => {
  const csrf = localStorage.getItem('csrf') || window.__CSRF
  if (csrf && cfg.method && cfg.method.toUpperCase() !== 'GET') {
    cfg.headers['X-CSRF-Token'] = csrf
  }
  return cfg
})

export default api