<template>
  <div class="layout">
    <!-- Accessibility skip link -->
    <a class="skip-link" href="#main">Skip to main content</a>

    <!-- Sticky nav bar -->
    <NavBar />

    <!-- Hero only on Home route -->
    <header v-if="$route.name==='home'" class="hero-box" aria-label="Elderberry Place header">
      <img src="/ebheader.svg" alt="Elderberry Place header" class="hero-img" />
    </header>

    <!-- Page content -->
    <main id="main">
      <RouterView />
    </main>
    <!-- Site footer -->
    <SiteFooter />
  </div>
</template>

<script setup>
import NavBar from './components/NavBar.vue'
import SiteFooter from './components/SiteFooter.vue'


</script>