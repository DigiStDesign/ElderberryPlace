<?php
// db.php — SQLite database connection for quick testing

try {
    // Use SQLite for quick setup
    $dsn = "sqlite:" . __DIR__ . "/elderberry.db";
    $pdo = new PDO($dsn);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create users table if it doesn't exist
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            full_name TEXT NOT NULL,
            email TEXT,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");
    
    // Insert test users if table is empty
    $count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($count == 0) {
        $pdo->exec("
            INSERT INTO users (username, full_name, email, password_hash, role) VALUES
            ('admin',    'Admin User',      'admin@elderberry.com',    '" . md5('admin') . "',    'ADMIN'),
            ('staff',    'Staff Member',    'staff@elderberry.com',    '" . md5('staff') . "',    'STAFF'),
            ('resident', 'Resident User',   'resident@elderberry.com', '" . md5('resident') . "', 'RESIDENT'),
            ('visitor',  'Visitor User',    'visitor@elderberry.com',  '" . md5('visitor') . "',  'VISITOR')
        ");
    }
    
    // Make $pdo available globally for the API
    $GLOBALS['pdo'] = $pdo;
    
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}