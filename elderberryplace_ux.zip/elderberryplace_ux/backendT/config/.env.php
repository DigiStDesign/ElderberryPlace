<?php
// Database configuration
$DB_HOST = '127.0.0.1';
$DB_PORT = 3306;
$DB_NAME = 'elderberry';
$DB_USER = 'root';
$DB_PASS = '';