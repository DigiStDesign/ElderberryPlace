<?php
// simple_db_test.php
echo "Testing database connection...\n";

// Check if PDO is available
if (!class_exists('PDO')) {
    echo "ERROR: PDO is not available!\n";
    echo "You need to install PHP with PDO support.\n";
    exit(1);
}

echo "PDO is available.\n";

// Test SQLite connection
try {
    $dsn = "sqlite:" . __DIR__ . "/config/elderberry.db";
    echo "Connecting to: $dsn\n";
    
    $pdo = new PDO($dsn);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully!\n";
    
    // Create users table if it doesn't exist
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            full_name TEXT NOT NULL,
            email TEXT,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");
    echo "Users table created/verified.\n";
    
    // Insert test users if table is empty
    $count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    echo "Current users in database: $count\n";
    
    if ($count == 0) {
        $pdo->exec("
            INSERT INTO users (username, full_name, email, password_hash, role) VALUES
            ('admin',    'Admin User',      'admin@elderberry.com',    '" . md5('admin') . "',    'ADMIN'),
            ('staff',    'Staff Member',    'staff@elderberry.com',    '" . md5('staff') . "',    'STAFF'),
            ('resident', 'Resident User',   'resident@elderberry.com', '" . md5('resident') . "', 'RESIDENT'),
            ('visitor',  'Visitor User',    'visitor@elderberry.com',  '" . md5('visitor') . "',  'VISITOR')
        ");
        echo "Test users inserted.\n";
    }
    
    // List all users
    $users = $pdo->query("SELECT username, role, password_hash FROM users")->fetchAll(PDO::FETCH_ASSOC);
    echo "\nUsers in database:\n";
    foreach ($users as $user) {
        echo "- {$user['username']} ({$user['role']}) - hash: {$user['password_hash']}\n";
    }
    
    echo "\nDatabase setup complete!\n";
    echo "You can now login with admin/admin\n";
    
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage() . "\n";
}
?>