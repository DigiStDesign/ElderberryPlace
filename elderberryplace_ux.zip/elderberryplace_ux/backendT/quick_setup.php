<?php
// quick_setup.php - Test script to create database and users
require_once __DIR__ . '/config/db.php';

try {
    // First try to create the database
    $pdo_no_db = new PDO("mysql:host=127.0.0.1", 'root', '');
    $pdo_no_db->exec("CREATE DATABASE IF NOT EXISTS elderberry CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "Database created successfully.\n";
    
    // Now connect to the specific database
    $dsn = "mysql:host=127.0.0.1;dbname=elderberry;charset=utf8";
    $pdo = new PDO($dsn, 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create users table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(64) NOT NULL UNIQUE,
            full_name VARCHAR(190) NOT NULL,
            email VARCHAR(120) NULL,
            password_hash VARCHAR(255) NOT NULL,
            role ENUM('ADMIN','STAFF','RESIDENT','VISITOR') NOT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8
    ");
    
    // Insert test users
    $pdo->exec("
        INSERT IGNORE INTO users (username, full_name, email, password_hash, role) VALUES
        ('admin',    'Admin User',      'admin@elderberry.com',    '" . md5('admin') . "',    'ADMIN'),
        ('staff',    'Staff Member',    'staff@elderberry.com',    '" . md5('staff') . "',    'STAFF'),
        ('resident', 'Resident User',   'resident@elderberry.com', '" . md5('resident') . "', 'RESIDENT'),
        ('visitor',  'Visitor User',    'visitor@elderberry.com',  '" . md5('visitor') . "',  'VISITOR')
    ");
    
    echo "Users table created and test users added.\n";
    echo "You can now login with:\n";
    echo "- Username: admin, Password: admin\n";
    echo "- Username: staff, Password: staff\n";
    echo "- Username: resident, Password: resident\n";
    echo "- Username: visitor, Password: visitor\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>