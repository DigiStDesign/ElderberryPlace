<?php
// test_auth.php - Test the authentication endpoint directly
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/api/lib/http.php';
require_once __DIR__ . '/api/lib/auth_api.php';
require_once __DIR__ . '/api/lib/db_api.php';
require_once __DIR__ . '/api/v1/AuthController.php';

// Set content type
header('Content-Type: application/json');

// Simulate POST request
$_SERVER['REQUEST_METHOD'] = 'POST';

// Test with admin credentials
$test_input = json_encode([
    'username' => 'admin',
    'password' => 'admin'
]);

// Mock the input
file_put_contents('php://temp', $test_input);

echo "Testing login with admin/admin...\n";

try {
    // Check if users exist first
    $pdo = api_db();
    $users = $pdo->query("SELECT username, role FROM users")->fetchAll(PDO::FETCH_ASSOC);
    echo "Users in database:\n";
    foreach ($users as $user) {
        echo "- {$user['username']} ({$user['role']})\n";
    }
    
    // Test a direct database query
    $st = $pdo->prepare("SELECT id, username, full_name, role, is_active, password_hash FROM users WHERE username = ?");
    $st->execute(['admin']);
    $admin_user = $st->fetch(PDO::FETCH_ASSOC);
    
    if ($admin_user) {
        echo "\nAdmin user found:\n";
        echo "- Username: {$admin_user['username']}\n";
        echo "- Role: {$admin_user['role']}\n";
        echo "- Active: {$admin_user['is_active']}\n";
        echo "- Password hash: {$admin_user['password_hash']}\n";
        echo "- Expected hash: " . md5('admin') . "\n";
        echo "- Match: " . (strtolower($admin_user['password_hash']) === md5('admin') ? 'YES' : 'NO') . "\n";
    } else {
        echo "\nNo admin user found!\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>